<?php
// 1. Olvasd be a data.json állományt asszociatív tömbként. (1 pont)
// Fájlból olvasás: https://www.php.net/manual/en/function.file-get-contents.php
// JSON Feldolgozása: https://www.php.net/manual/en/function.json-decode.php
$file = file_get_contents("data.json");
$tomb = json_decode($file,true)

// 2. Jelenítsd meg az adatokat a táblázat soraiként. (1 pont)
//kész
// 3. A 2000-ben, és annál később kiadott könyveknél a könyv címe legyen "bold", tehát vastagon-szedett! (1 pont)
// (Pl. <b> tagek segítségével!)
// A megoldáshoz célszerű a "substr()" függvény használata.
//kész

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Garfield Books</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <table>
        <tr>
            <th>Könyv Címe (title)</th>
            <th>Kiadás dátuma (release_date)</th>
        </tr>
        <?php foreach($tomb as $line) { ?>
        <tr>
            <?php if(intval(substr($line["release_date"],-4)) > 2000) { ?>
                <td><b><?= $line["title"] ?></b></td>
                <td><b><?= $line["release_date"] ?></b></td>
            <?php } else { ?>
                <td><?= $line["title"] ?></td>
                <td><?= $line["release_date"] ?></td>
            <?php } ?>
        </tr>
        <?php } ?>
    </table>
</body>

</html>